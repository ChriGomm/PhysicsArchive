#include "examples.h"
#include <iostream>

void hello_world() { std::cout << "Hello World!\n"; }
