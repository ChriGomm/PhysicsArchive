#pragma once

/**
 * @brief Prints the "Hello World!" string to the terminal.
 * 
 */
void hello_world();