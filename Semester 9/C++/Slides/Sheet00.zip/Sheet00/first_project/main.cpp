#include "submission/examples.h"
#include <cstdlib>

int main() {
  hello_world();
  return EXIT_SUCCESS;
}