#include "submission/exercise_00.h"
#include <cstdlib>

int main() {
  // Here we call the "run_exercise00()" function that was declared in
  // submission/exercise_00.h and is implemented in submission/exercise_00.cpp
  run_exercise00();
  return EXIT_SUCCESS;
}
