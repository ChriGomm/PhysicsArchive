#include "exercise_00.h"
#include <iostream>

int add(int a, int b) {
  // TODO
  // a) Zip the submission folder as it is and upload it on InfoMark
  // b) Replace 'return 0;' with 'return asdf', zip the submission folder and
  // upload it on InfoMark.
  // c) Replace 'return 0;' with 'return 2;', zip the submission folder and
  // upload it to InfoMark.
  // d) Replace 'return 0;' with 'return a + b;', zip the submission folder and
  // upload it to InfoMark.
  return 0;
}

void run_exercise00() {
  // This will print out "1 + 1 = 2" when you are done with 0.5.c)
  std::cout << 1 << " + " << 1 << " = " << add(1, 1) << "\n";
}